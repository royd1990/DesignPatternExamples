package Observer2;

public class SubjectImpl {

}
